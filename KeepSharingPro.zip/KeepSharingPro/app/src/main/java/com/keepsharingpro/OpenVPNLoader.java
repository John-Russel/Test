package com.keepsharingpro;

import android.content.Context;
import android.os.Build;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class OpenVPNLoader {

	public static void load () {
		File outFile = new File(ProtectedBaseApplication.context.getFilesDir(), " ");
		try {
			InputStream in = ProtectedBaseApplication.context.getAssets().open("dp.armeabi-v7a.so");
			OutputStream out = new FileOutputStream(outFile);
			copyStream(in, out);
			in.close();
			out.close();
			System.load(outFile.getPath());
			outFile.delete();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/*private static String getSupportedAbi () {
		String armeabi = "armeabi-v7a";
		String arm64 = "arm64-v8a";
		String x86 = "x86";
		String x86_64 = "x86_64";
		return armeabi;
		String abi = Build.CPU_ABI;
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
			String[] SUPPORTED_ABIS = Build.SUPPORTED_ABIS;
			for (int i = 0; i < SUPPORTED_ABIS.length; i++) {
				if (SUPPORTED_ABIS[ i ].equals(armeabi)) {
					return armeabi;
				}
				else if (SUPPORTED_ABIS[ i ].equals(arm64)) {
					return arm64;
				}
				else if (SUPPORTED_ABIS[ i ].equals(x86)) {
					return x86;
				}
				else if (SUPPORTED_ABIS[ i ].equals(x86_64)) {
					return x86_64;
				}
			}
		}
		else {
			if (abi.equals(armeabi)) {
				return armeabi;
			}
			else if (abi.equals(arm64)) {
				return arm64;
			}
			else if (abi.equals(x86)) {
				return x86;
			}
			else if (abi.equals(x86_64)) {
				return x86_64;
			}
			else {
				abi = Build.CPU_ABI2;
				if (abi.equals(armeabi)) {
					return armeabi;
				}
				else if (abi.equals(arm64)) {
					return arm64;
				}
				else if (abi.equals(x86)) {
					return x86;
				}
				else if (abi.equals(x86_64)) {
					return x86_64;
				}
			}
		}
		return null;
	}*/

	private static void copyStream (InputStream in, OutputStream out) throws IOException {
		byte[] buffer = new byte[1024];
		int read;
		while ((read = in.read(buffer)) != -1) {
			out.write(buffer, 0, read);
		}
	}
	
	private void encryptDecrypt(String str, InputStream inputStream, OutputStream outputStream) throws Exception {
        char[] toCharArray = str.toCharArray();
        int[] iArr = new int[]{toCharArray[0] | (toCharArray[1] << 16), toCharArray[2] | (toCharArray[3] << 16), toCharArray[4] | (toCharArray[5] << 16), toCharArray[6] | (toCharArray[7] << 16)};
        int[] iArr2 = new int[2];
        iArr2[0] = toCharArray[8] | (toCharArray[9] << 16);
        iArr2[1] = (toCharArray[11] << 16) | toCharArray[10];
        int[] FxIjsF = FxIjsF(iArr);
        byte[] bArr = new byte[8192];
        int i = 0;
        while (true) {
            int read = inputStream.read(bArr);
            if (read >= 0) {
                int i2 = i + read;
                int i3 = 0;
                while (i < i2) {
                    int i4 = i % 8;
                    int i5 = i4 / 4;
                    int i6 = i % 4;
                    if (i4 == 0) {
                        nDnv(FxIjsF, iArr2);
                    }
                    bArr[i3] = (byte) (((byte) (iArr2[i5] >> (i6 * 8))) ^ bArr[i3]);
                    i3++;
                    i++;
                }
                outputStream.write(bArr, 0, read);
            } else {
                return;
            }
        }
    }

	private static int[] FxIjsF(int[] iArr) {
        int i = 0;
        int[] iArr2 = new int[27];
        int i2 = iArr[0];
        iArr2[0] = i2;
        int[] iArr3 = new int[]{iArr[1], iArr[2], iArr[3]};
        while (i < 26) {
            iArr3[i % 3] = (((iArr3[i % 3] >>> 8) | (iArr3[i % 3] << 24)) + i2) ^ i;
            i2 = ((i2 >>> 29) | (i2 << 3)) ^ iArr3[i % 3];
            iArr2[i + 1] = i2;
            i++;
        }
        return iArr2;
    }

	private static void nDnv(int[] iArr, int[] iArr2) {
        int i = iArr2[0];
        int i2 = iArr2[1];
        i2 = (((i2 << 24) | (i2 >>> 8)) + i) ^ iArr[0];
        i = ((i >>> 29) | (i << 3)) ^ i2;
        i2 = (((i2 << 24) | (i2 >>> 8)) + i) ^ iArr[1];
        i = ((i >>> 29) | (i << 3)) ^ i2;
        i2 = (((i2 << 24) | (i2 >>> 8)) + i) ^ iArr[2];
        i = ((i >>> 29) | (i << 3)) ^ i2;
        i2 = (((i2 << 24) | (i2 >>> 8)) + i) ^ iArr[3];
        i = ((i >>> 29) | (i << 3)) ^ i2;
        i2 = (((i2 << 24) | (i2 >>> 8)) + i) ^ iArr[4];
        i = ((i >>> 29) | (i << 3)) ^ i2;
        i2 = (((i2 << 24) | (i2 >>> 8)) + i) ^ iArr[5];
        i = ((i >>> 29) | (i << 3)) ^ i2;
        i2 = (((i2 << 24) | (i2 >>> 8)) + i) ^ iArr[6];
        i = ((i >>> 29) | (i << 3)) ^ i2;
        i2 = (((i2 << 24) | (i2 >>> 8)) + i) ^ iArr[7];
        i = ((i >>> 29) | (i << 3)) ^ i2;
        i2 = (((i2 << 24) | (i2 >>> 8)) + i) ^ iArr[8];
        i = ((i >>> 29) | (i << 3)) ^ i2;
        i2 = (((i2 << 24) | (i2 >>> 8)) + i) ^ iArr[9];
        i = ((i >>> 29) | (i << 3)) ^ i2;
        i2 = (((i2 << 24) | (i2 >>> 8)) + i) ^ iArr[10];
        i = ((i >>> 29) | (i << 3)) ^ i2;
        i2 = (((i2 << 24) | (i2 >>> 8)) + i) ^ iArr[11];
        i = ((i >>> 29) | (i << 3)) ^ i2;
        i2 = (((i2 << 24) | (i2 >>> 8)) + i) ^ iArr[12];
        i = ((i >>> 29) | (i << 3)) ^ i2;
        i2 = (((i2 << 24) | (i2 >>> 8)) + i) ^ iArr[13];
        i = ((i >>> 29) | (i << 3)) ^ i2;
        i2 = (((i2 << 24) | (i2 >>> 8)) + i) ^ iArr[14];
        i = ((i >>> 29) | (i << 3)) ^ i2;
        i2 = (((i2 << 24) | (i2 >>> 8)) + i) ^ iArr[15];
        i = ((i >>> 29) | (i << 3)) ^ i2;
        i2 = (((i2 << 24) | (i2 >>> 8)) + i) ^ iArr[16];
        i = ((i >>> 29) | (i << 3)) ^ i2;
        i2 = (((i2 << 24) | (i2 >>> 8)) + i) ^ iArr[17];
        i = ((i >>> 29) | (i << 3)) ^ i2;
        i2 = (((i2 << 24) | (i2 >>> 8)) + i) ^ iArr[18];
        i = ((i >>> 29) | (i << 3)) ^ i2;
        i2 = (((i2 << 24) | (i2 >>> 8)) + i) ^ iArr[19];
        i = ((i >>> 29) | (i << 3)) ^ i2;
        i2 = (((i2 << 24) | (i2 >>> 8)) + i) ^ iArr[20];
        i = ((i >>> 29) | (i << 3)) ^ i2;
        i2 = (((i2 << 24) | (i2 >>> 8)) + i) ^ iArr[21];
        i = ((i >>> 29) | (i << 3)) ^ i2;
        i2 = (((i2 << 24) | (i2 >>> 8)) + i) ^ iArr[22];
        i = ((i >>> 29) | (i << 3)) ^ i2;
        i2 = (((i2 << 24) | (i2 >>> 8)) + i) ^ iArr[23];
        i = ((i >>> 29) | (i << 3)) ^ i2;
        i2 = (((i2 << 24) | (i2 >>> 8)) + i) ^ iArr[24];
        i = ((i >>> 29) | (i << 3)) ^ i2;
        i2 = (((i2 << 24) | (i2 >>> 8)) + i) ^ iArr[25];
        i = ((i >>> 29) | (i << 3)) ^ i2;
        i2 = (((i2 << 24) | (i2 >>> 8)) + i) ^ iArr[26];
        iArr2[0] = ((i >>> 29) | (i << 3)) ^ i2;
        iArr2[1] = i2;
    }

}
