package com.keepsharingpro;

import android.util.Log;
import org.json.JSONException;
import org.json.JSONObject;

import static com.keepsharingpro.ProtectedBaseApplication.*;
import java.io.IOException;

public class OpenVPNConfig {
	String name;
	String content;
	String cert;
	//String user;
	//String pass;
	String message;
	
	public class Cert{
		String name;
		String value;
		
		public Cert(String name, String value){
			this.name = name;
			this.value = value;
		}
	}
	
	public OpenVPNConfig (JSONObject conf) {
		try {
			this.name = conf.getString("Name");
			this.content = conf.getString("Content");
			this.cert = conf.getString("Cert");
			//this.user = conf.getString("Username");
			//this.pass = conf.getString("Password");
			this.message = conf.getString("Message");
		} catch (JSONException e) {
			e.printStackTrace();
		}
	}

	public String toString (boolean dubeg) {
		try {
			String config = new JSONObject()
				  .put("Name", this.name)
				  .put("Content", this.content)
				  .put("Cert", this.cert)
				  //.put("Username", this.user)
				  //.put("Password", this.pass)
				  .put("Message", this.message).toString();
			if(dubeg) Log.i("Config", config);
			return config;
		} catch (JSONException e) {
			e.printStackTrace();
			return null;
		}
	}
	
	@Override
	public String toString () {
		return name;
	}

}
