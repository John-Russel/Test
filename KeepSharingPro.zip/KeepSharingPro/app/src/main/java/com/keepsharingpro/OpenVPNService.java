package com.keepsharingpro;

import android.app.Notification;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.net.VpnService;
import android.os.Binder;
import android.os.IBinder;
import android.os.SystemClock;
import java.util.Date;
import net.openvpn.openvpn.ClientAPI_TransportStats;
import org.json.JSONException;
import org.json.JSONObject;

public class OpenVPNService extends VpnService {
	public static String ACTION_BIND = "ACTION_BIND";
	public static String ACTION_CONNECT = "ACTION_CONNECT";
	public static String ACTION_DISCONNECT = "ACTION_DISCONNECT";

	private IBinder binder = new LocalBinder();
	private OpenVPNThread thread;
	private Notification.Builder notification;
	private OpenVPNConfig config;

	public boolean active = false;

	public class LocalBinder extends Binder {

		public OpenVPNService getService () {
			return OpenVPNService.this;
		}

	}
	
	static {
		OpenVPNLoader.load();
	}

	private void startConnection () {
		if (active)
			return;
		OpenVPNThread thread = new OpenVPNThread(this, new Builder(), config);
		thread.start();
		this.thread = thread;
        this.active = true;
		startNotification();
	}

	public String getGuiVersion () {
        String versionName = "1.0";
        int versionCode = 0;
        try {
            PackageInfo pi = getPackageManager().getPackageInfo(getPackageName(), 0);
            versionName = pi.versionName;
            versionCode = pi.versionCode;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return String.format("%s %s-%d", new Object[]{getPackageName(), versionName, Integer.valueOf(versionCode)});
    }

	private void startNotification () {
		if (notification == null & config != null) {
			notification = new Notification.Builder(this)
				.setSmallIcon(R.mipmap.ic_launcher)
				.setContentTitle(config.name)
				.setOnlyAlertOnce(true)
				.setOngoing(true)
				.setWhen(new Date().getTime())
				.setContentIntent(PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class), 0));
			startForeground(1, notification.build());
		}
	}

	public void updateNotification (String text) {
		if (notification != null) {
			notification
				.setContentText(text);
			startForeground(1, notification.build());
		}
	}

	private void stopConnection () {
		if (active) {
			thread.stop();
			thread.pause_on_connection_timeout();
			active = false;
			stopNotification();
			stopSelf();
		}
	}

	private void stopNotification () {
		if (notification != null) {
			notification = null;
			stopForeground(true);
		}
	}

	@Override
	public void onCreate () {
		super.onCreate();
	}

	@Override
	public int onStartCommand (Intent intent, int flags, int startId) {
		String action = intent.getAction();
		if (action == ACTION_CONNECT) {
			try {
				config = new OpenVPNConfig(new JSONObject(intent.getStringExtra("conf")));
			} catch (JSONException e) {
				e.printStackTrace();
			}
			startConnection();
		} if (action == ACTION_DISCONNECT)
			stopConnection();
		return super.onStartCommand(intent, flags, startId);
	}

	@Override
	public IBinder onBind (Intent intent) {
		if (intent == null | !intent.getAction().equals(ACTION_BIND))
			return super.onBind(intent);
		return binder;
	}

	@Override
	public boolean onUnbind (Intent intent) {
		return super.onUnbind(intent);
	}

	@Override
	public void onDestroy () {
		stopConnection();
		super.onDestroy();
	}

	@Override
	public void onRevoke () {
		stopConnection();
		super.onRevoke();
	}

}

