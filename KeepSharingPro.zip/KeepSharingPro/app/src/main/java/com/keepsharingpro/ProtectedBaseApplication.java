package com.keepsharingpro;

import android.app.Application;
import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONException;

public class ProtectedBaseApplication extends Application {
	public static Context context;
	public static SharedPreferences pref;
	public static SharedPreferences.Editor editor;

	@Override
	public void onCreate () {
		super.onCreate();
	}

	@Override
	protected void attachBaseContext (Context base) {
		super.attachBaseContext(base);
		context = base;
		pref = PreferenceManager.getDefaultSharedPreferences(base);
		editor = pref.edit();
		
		
	}
	
	public static String readStream (InputStream input) {
		try {
			BufferedReader reader = new BufferedReader(new InputStreamReader(input));
			StringBuilder builder = new StringBuilder();
			int read;
			char[] chars = new char[2048];
			while ((read = reader.read(chars, 0, chars.length)) != -1) {
				builder.append(chars, 0, read);
			}
			reader.close();
			return builder.toString();
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
	
	public static ArrayList<OpenVPNConfig> getServers(JSONArray serverArray){
		ArrayList<OpenVPNConfig> servers = new ArrayList<OpenVPNConfig>();
		for(int i = 0; i < serverArray.length(); i++){
			try {
				servers.add(new OpenVPNConfig((JSONObject) serverArray.get(i)));
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return servers;
	}
	
	public static String getCert(String cert, JSONArray certArray){
		for(int i = 0; i < certArray.length(); i++){
			try {
				JSONObject certObject = (JSONObject) certArray.get(i);
				String name = certObject.getString("Name");
				if(cert.equals(name))
					return certObject.getString("Value");
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return null;
	}
	
	public static String render_duration(int duration) {
        int seconds = duration % 60;
        int minutes = (duration / 60) % 60;
        return String.format("%02d:%02d:%02d", new Object[]{Integer.valueOf(duration / 3600), Integer.valueOf(minutes), Integer.valueOf(seconds)});
    }
}
