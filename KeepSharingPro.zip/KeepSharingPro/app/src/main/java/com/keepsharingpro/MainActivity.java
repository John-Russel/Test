package com.keepsharingpro;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.net.Uri;
import android.net.VpnService;
import android.os.Bundle;
import android.os.Environment;
import android.os.IBinder;
import android.text.Html;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.keepsharingpro.R;
import java.io.File;
import java.util.ArrayList;
import org.json.JSONArray;
import org.json.JSONObject;

import static com.keepsharingpro.ProtectedBaseApplication.*;
import android.text.Editable;

public class MainActivity extends Activity implements TextWatcher, View.OnClickListener, AdapterView.OnItemSelectedListener {

	private LinearLayout main;
	private TextView duration;
	private Spinner serverList;
	private TextView message;
	private EditText username, password;
	private Button connect;
	private LinearLayout update, about;

	private ArrayList<OpenVPNConfig> servers;
	private ArrayAdapter<OpenVPNConfig> adapter;

	private ProgressDialog progressDialog;

	private OpenVPNService service;
	private ServiceConnection connection = new ServiceConnection(){

		@Override
		public void onServiceConnected (ComponentName p1, IBinder p2) {
			service = ((OpenVPNService.LocalBinder)p2).getService();
		}

		@Override
		public void onServiceDisconnected (ComponentName p1) {
			service = null;
		}
	};
	private long downloadId;
	private File path;
	private Uri destUri;
	private BroadcastReceiver receiver = new BroadcastReceiver(){

		@Override
		public void onReceive (Context p1, Intent p2) {
			switch(p2.getAction()){
				case DownloadManager.ACTION_DOWNLOAD_COMPLETE:
					if (downloadId == p2.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1)) {
						Toast.makeText(getApplicationContext(), "Download completed", Toast.LENGTH_SHORT).show();
						startActivity(new Intent(Intent.ACTION_VIEW).setDataAndType(destUri, "application/vnd.android.package-archive"));
					}
					break;
				case "Stats":
					duration.setText(render_duration(p2.getIntExtra("Duration", 0)));
					break;
				case "Event":
					String Name = p2.getStringExtra("Name");
					progressDialog.setMessage(Name);
					progressDialog.show();
					if(Name.equals("DISCONNECTED")||Name.equals("CONNECTED"))
						progressDialog.dismiss();
					if(p2.getBooleanExtra("Error", false)){
						disconnect();
						new AlertDialog.Builder(MainActivity.this)
						.setTitle(Name)
						.setMessage(p2.getStringExtra("Info"))
						.setPositiveButton("OK", null)
						.show();
					}
					break;
			}
		}
	};

    @Override
    protected void onCreate (Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		bindService(new Intent(this, OpenVPNService.class).setAction(OpenVPNService.ACTION_BIND), connection, 65);
		IntentFilter filter = new IntentFilter();
		filter.addAction(DownloadManager.ACTION_DOWNLOAD_COMPLETE);
		filter.addAction("Stats");
		filter.addAction("Event");
		registerReceiver(receiver, filter);

		main = findViewById(R.id.mainLinearLayout3);
		duration = findViewById(R.id.mainTextView1);
		serverList = findViewById(R.id.mainSpinner1);
		message = findViewById(R.id.mainTextView2);
		username = findViewById(R.id.mainEditText1);
		password = findViewById(R.id.mainEditText2);
		connect = findViewById(R.id.mainButton1);
		update = findViewById(R.id.mainLinearLayout1);
		about = findViewById(R.id.mainLinearLayout2);

		servers = new ArrayList<OpenVPNConfig>();
		adapter = new ArrayAdapter<OpenVPNConfig>(this, android.R.layout.simple_list_item_1, servers);

		progressDialog = new ProgressDialog(this);

		path = new File(Environment.getExternalStorageDirectory(), getString(R.string.app_name));
		File app = new File(path, "app.apk");
		if(app.exists())
			app.delete();
		destUri = Uri.fromFile(app);
		path.mkdir();
		
		serverList.setOnItemSelectedListener(this);
		username.addTextChangedListener(this);
		password.addTextChangedListener(this);
		connect.setOnClickListener(this);
		update.setOnClickListener(this);
		about.setOnClickListener(this);
		
		progressDialog.setButton(AlertDialog.BUTTON_POSITIVE, "CANCEL", new DialogInterface.OnClickListener(){

				@Override
				public void onClick (DialogInterface p1, int p2) {
					disconnect();
				}
			});
		progressDialog.setCancelable(false);
		progressDialog.setCanceledOnTouchOutside(false);

		serverList.setAdapter(adapter);

		/*if(BuildConfig.DEBUG){
			try {
				JSONObject config = new JSONObject(readStream(new FileInputStream("/storage/emulated/0/TestConfig/config.json")));
				servers.addAll(getServers(config.getJSONArray("Servers")));
				adapter.notifyDataSetChanged();
				editor.putString("Certs", config.getJSONArray("Certs").toString())
				.putString("Config Version", config.getString("Version"))
				.apply();
			} catch (Exception e) {
				e.printStackTrace();
			} 
		}*/
		if(pref.getBoolean("firstRun", true))
			main.setVisibility(View.GONE);
		else{
			main.setVisibility(View.VISIBLE);
			try {
				servers.addAll(getServers(new JSONArray(pref.getString("Servers", ""))));
				adapter.notifyDataSetChanged();
			} catch (Exception e) {
				e.printStackTrace();
			}
			username.setText(pref.getString("Username", ""));
			password.setText(pref.getString("Password", ""));
		}
    }

	

	@Override
	public void onItemSelected (AdapterView<?> p1, View p2, int p3, long p4) {
		switch (p1.getId()) {
			case R.id.mainSpinner1:
				message.setText(servers.get(p3).message);
				editor.putInt("serverSelection", p3).apply();
				break;
		}
	}

	@Override
	public void onNothingSelected (AdapterView<?> p1) {
		// TODO: Implement this method
	}

	@Override
	public void beforeTextChanged (CharSequence p1, int p2, int p3, int p4) {
		// TODO: Implement this method
	}

	@Override
	public void onTextChanged (CharSequence p1, int p2, int p3, int p4) {
		// TODO: Implement this method
	}

	@Override
	public void afterTextChanged (Editable p1) {
		if(p1==username.getText()){
			editor.putString("Username", p1.toString()).apply();
		}
		if(p1==password.getText()){
			editor.putString("Password", p1.toString()).apply();
		}
	}
	
	private void connect () {
		startService(new Intent(MainActivity.this, OpenVPNService.class)
					 .setAction(OpenVPNService.ACTION_CONNECT)
					 .putExtra("conf", servers.get(pref.getInt("serverSelection", 0)).toString(BuildConfig.DEBUG)));
		setEnabled(false);
	}

	private void disconnect () {
		startService(new Intent(MainActivity.this, OpenVPNService.class)
					 .setAction(OpenVPNService.ACTION_DISCONNECT));
		setEnabled(true);
	}
	
	private void setEnabled(boolean enabled){
		duration.setVisibility(enabled?View.GONE:View.VISIBLE);
		serverList.setEnabled(enabled);
		username.setEnabled(enabled);
		password.setEnabled(enabled);
		connect.setText(enabled?"CONNECT":"DISCONNECT");
	}

	@Override
	public void onClick (View p1) {
		switch (p1.getId()) {
			case R.id.mainButton1:
				if(username.getText().toString().isEmpty()||password.getText().toString().isEmpty()){
					Toast.makeText(this, "Username/Password can't be empty", Toast.LENGTH_SHORT).show();
					return;
				}
				Intent intent = VpnService.prepare(getApplicationContext());
				if (intent != null) {
					try {
						startActivityForResult(intent, 1);
						return;
					} catch (Exception e) {
						e.printStackTrace();
						return;
					}
				}
				if(service!=null&service.active){
					disconnect();
				}else{
					connect();
				}
				break;
			case R.id.mainLinearLayout1:
				View view = getLayoutInflater().inflate(R.layout.update, null);
				Button appUpdate = view.findViewById(R.id.updateButton1);
				Button configUpdate = view.findViewById(R.id.updateButton2);
				appUpdate.setOnClickListener(this);
				configUpdate.setOnClickListener(this);
				AlertDialog.Builder update = new AlertDialog.Builder(this);
				update.setTitle("Online Update");
				update.setView(view);
				update.setPositiveButton("CANCEL", null);
				update.show();
				break;
			case R.id.updateButton1:
				try {
					JsonObjectRequest req = new JsonObjectRequest("https://pastebin.com/raw/LJJzdEv7", null,
						new Response.Listener<JSONObject>() {
							@Override
							public void onResponse (JSONObject response) {
								try {
									final String version = response.getString("Version");
									final String link = response.getString("Link");
									if (!version.equals(pref.getString("App Version", "1.0"))) {
										Toast.makeText(getApplicationContext(), "Update available!", Toast.LENGTH_SHORT).show();
										new AlertDialog.Builder(MainActivity.this)
											.setMessage(Html.fromHtml("<b>What's new •</b><br><br>"+response.getString("What's new •")))
											.setPositiveButton("DOWNLOAD", new DialogInterface.OnClickListener(){

												@Override
												public void onClick (DialogInterface p1, int p2) {
													DownloadManager.Request request = new DownloadManager.Request(Uri.parse(link))
														.setTitle("AppUpdate")
														.setDescription("Downloading...")
														.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE)
														.setDestinationUri(destUri)
														.setAllowedOverMetered(true)
														.setAllowedOverRoaming(true);
													downloadId = ((DownloadManager) getSystemService(DOWNLOAD_SERVICE)).enqueue(request);
													Toast.makeText(getApplicationContext(), "Download started", Toast.LENGTH_SHORT).show();
												}
											})
											.setNegativeButton("CANCEL", null)
											.create().show();
									}
									else {
										Toast.makeText(getApplicationContext(), "No update available", Toast.LENGTH_SHORT).show();
									}
								} catch (Exception e) {
									e.printStackTrace();
								}
							}
						}, new Response.ErrorListener() {
							@Override
							public void onErrorResponse (VolleyError error) {
								//VolleyLog.e("Error: ", error.getMessage());
							}
						});
					req.setShouldCache(false);
					// add the request object to the queue to be executed
					Volley.newRequestQueue(getApplicationContext()).add(req);
				} catch (Exception e) {
					e.printStackTrace();
				}
				break;
			case R.id.updateButton2:
				try {
					JsonObjectRequest req = new JsonObjectRequest("https://pastebin.com/raw/d7CMMx1V", null,
						new Response.Listener<JSONObject>() {
							@Override
							public void onResponse (JSONObject response) {
								try {
									final String version = response.getString("Version");
									final JSONArray servers = response.getJSONArray("Servers");
									final JSONArray certs = response.getJSONArray("Certs");
									if (!version.equals(pref.getString("Config Version", ""))) {
										Toast.makeText(getApplicationContext(), "Update available!", Toast.LENGTH_SHORT).show();
										new AlertDialog.Builder(MainActivity.this)
											.setMessage(Html.fromHtml("<b>What's new •</b><br><br>"+response.getString("What's new •")))
											.setPositiveButton("APPLY", new DialogInterface.OnClickListener(){

												@Override
												public void onClick (DialogInterface p1, int p2) {
													editor.putBoolean("firstRun", false).putString("Config Version", version.toString())
														.putString("Servers", servers.toString())
														.putString("Certs", certs.toString())
														.apply();
													startActivity(new Intent(getApplicationContext(), MainActivity.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK));
													finish();
													Toast.makeText(getApplicationContext(), "Support the app by donating", Toast.LENGTH_SHORT).show();
												}
											})
											.setNegativeButton("CANCEL", null)
											.create().show();
									}
									else {
										Toast.makeText(getApplicationContext(), "No update available", Toast.LENGTH_SHORT).show();
									}
								} catch (Exception e) {
									e.printStackTrace();
								}
							}
						}, new Response.ErrorListener() {
							@Override
							public void onErrorResponse (VolleyError error) {
								//VolleyLog.e("Error: ", error.getMessage());
							}
						});
					req.setShouldCache(false);
					// add the request object to the queue to be executed
					Volley.newRequestQueue(getApplicationContext()).add(req);
				} catch (Exception e) {
					e.printStackTrace();
				}
				break;
			case R.id.mainLinearLayout2:
				AlertDialog.Builder about = new AlertDialog.Builder(this);
				about.setTitle("About");
				about.setMessage(Html.fromHtml("© Copyright 2019, KeepSharing Team. All rights reserved<br><br><b>KeepSharing Pro</b><br><br>KeepSharing Pro is based on OpenVPN Connect, Modified and Developed by John Russel Zipagan<br><br><br><b>Donate</b><br><br>Support the app by donating (any amount)<br><br>"));
				about.setPositiveButton("CANCEL", null);
				about.show();
				break;
		}
	}

	@Override
	protected void onActivityResult (int requestCode, int resultCode, Intent data) {
		switch (requestCode) {
			case 1:
				if (resultCode == Activity.RESULT_OK) {
					connect();
				}
				break;
		}
		super.onActivityResult(requestCode, resultCode, data);
	}

	@Override
	protected void onRestoreInstanceState (Bundle savedInstanceState) {
		setEnabled(!savedInstanceState.getBoolean("Active", true));
		super.onRestoreInstanceState(savedInstanceState);
	}

	@Override
	protected void onSaveInstanceState (Bundle outState) {
		outState.putBoolean("Active", service.active);
		super.onSaveInstanceState(outState);
	}

	@Override
	protected void onDestroy () {
		unbindService(connection);
		unregisterReceiver(receiver);
		super.onDestroy();
	}

}
