package com.keepsharingpro;

import android.content.Intent;
import android.net.VpnService;
import android.os.SystemClock;
import android.util.Log;
import net.openvpn.openvpn.ClientAPI_Config;
import net.openvpn.openvpn.ClientAPI_Event;
import net.openvpn.openvpn.ClientAPI_LogInfo;
import net.openvpn.openvpn.ClientAPI_OpenVPNClient;
import net.openvpn.openvpn.ClientAPI_ProvideCreds;
import net.openvpn.openvpn.ClientAPI_Status;
import net.openvpn.openvpn.ClientAPI_TransportStats;

import static com.keepsharingpro.ProtectedBaseApplication.*;
import org.json.JSONArray;
import org.json.JSONException;

public class OpenVPNThread extends ClientAPI_OpenVPNClient implements Runnable {
    private OpenVPNService mService;
    private OpenVPNConfig mVp;
	private VpnService.Builder builder;
	private Thread thread;
	private long thread_started = 0;
	
	class StatusPoller implements Runnable {
		private long mSleeptime;
		boolean mStopped = false;

		public StatusPoller (long j) {
			this.mSleeptime = j;
		}

		public void run () {
			while (!this.mStopped) {
				try {
					Thread.sleep(this.mSleeptime);
				} catch (InterruptedException e) {
				}
				ClientAPI_TransportStats transport_stats = transport_stats();
				long bytesIn = transport_stats.getBytesIn();
				long bytesOut = transport_stats.getBytesOut();
				int duration = (int)(SystemClock.elapsedRealtime() - thread_started) / 1000;
				if(BuildConfig.DEBUG)
					Log.i("Status Poller", "In "+bytesIn+" Out "+bytesOut+" Duration "+duration);
				mService.sendBroadcast(new Intent("Stats").putExtra("Duration", duration));
			}
		}

		public void stop () {
			this.mStopped = true;
		}
	}

    public OpenVPNThread (OpenVPNService openVPNService, VpnService.Builder builder, OpenVPNConfig vpnProfile) {
        init_process();
        this.mService = openVPNService;
		this.builder = builder;
		this.mVp = vpnProfile;
        this.thread_started = SystemClock.elapsedRealtime();
    }
	
	public void start(){
		this.thread = new Thread(this, "OpenVPNThread");
		this.thread.start();
	}

    private boolean setConfig (String str) {
        ClientAPI_Config clientAPI_Config = new ClientAPI_Config();
        clientAPI_Config.setContent(str);
        clientAPI_Config.setConnTimeout(60);
        clientAPI_Config.setGuiVersion(mService.getGuiVersion());
        clientAPI_Config.setDisableClientCert(true);
        if (eval_config(clientAPI_Config).getError()) {
            return false;
        }
        return true;
    }

    @Override
    public void event (ClientAPI_Event clientAPI_Event) {
        mService.updateNotification(clientAPI_Event.getName());
		mService.sendBroadcast(new Intent("Event").putExtra("Name", clientAPI_Event.getName()).putExtra("Error", clientAPI_Event.getError()).putExtra("Info", clientAPI_Event.getInfo()));
    }

    @Override
    public void log (ClientAPI_LogInfo clientAPI_LogInfo) {
        if(BuildConfig.DEBUG)
			Log.i("Log", clientAPI_LogInfo.getText());
    }

    @Override
    public boolean pause_on_connection_timeout () {
        return false;
    }

    @Override
    public void run () {
        try {
			if (setConfig(mVp.content + "\n" + getCert(mVp.cert, new JSONArray(pref.getString("Certs", ""))))) {
				setUserPW();
				StatusPoller statusPoller = new StatusPoller(1000);
				new Thread(statusPoller, "Status Poller").start();
				ClientAPI_Status clientAPI_Status = super.connect();
				if (clientAPI_Status.getError()) {
					Log.e("OpenVPNThread", String.format("connect() error: %s: %s", clientAPI_Status.getStatus(), clientAPI_Status.getMessage()));
				}
				statusPoller.stop();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
    }

    void setUserPW () {
        ClientAPI_ProvideCreds clientAPI_ProvideCreds = new ClientAPI_ProvideCreds();
        clientAPI_ProvideCreds.setCachePassword(true);
        //clientAPI_ProvideCreds.setUsername(mVp.user);
        //clientAPI_ProvideCreds.setPassword(mVp.pass);
        clientAPI_ProvideCreds.setUsername(pref.getString("Username", ""));
        clientAPI_ProvideCreds.setPassword(pref.getString("Password", ""));
        provide_creds(clientAPI_ProvideCreds);
    }

    @Override
    public boolean socket_protect (int i) {
        return this.mService.protect(i);
    }

    @Override
    public void stop () {
        super.stop();
    }

	@Override
    public boolean tun_builder_new () {
		return true;
    }
	
	@Override
    public boolean tun_builder_set_remote_address (String str, boolean z) {
        return true;
    }
	
    @Override
    public boolean tun_builder_add_address(String address, int prefix_length, String gateway, boolean ipv6, boolean net30) {
		try {
			builder.addAddress(address, prefix_length);
			return true;
		} catch (Exception e) {
			return false;
		}
	}

    @Override
    public boolean tun_builder_reroute_gw(boolean ipv4, boolean ipv6, long flags) {
		try {
			if (ipv4) {
				builder.addRoute("0.0.0.0", 0);
			}
			if (!ipv6) {
				return true;
			}
			builder.addRoute("::", 0);
			return true;
		} catch (Exception e) {
			return false;
		}
	}

    @Override
	public boolean tun_builder_add_route(String address, int prefix_length, int metric, boolean ipv6) {
		try {
			builder.addRoute(address, prefix_length);
			return true;
		} catch (Exception e) {
			return false;
		}
    }
	
	@Override
    public boolean tun_builder_exclude_route(String address, int prefix_length, int metric, boolean ipv6) {
        return true;
    }
	
    @Override
    public boolean tun_builder_add_dns_server (String address, boolean ipv6) {
        try {
			builder.addDnsServer(address);
			return true;
		} catch (Exception e) {
			return false;
		}
    }

    @Override
    public boolean tun_builder_add_search_domain (String domain) {
        try {
			builder.addSearchDomain(domain);
			return true;
		} catch (Exception e) {
			return false;
		}
    }

    @Override
    public boolean tun_builder_set_layer (int i) {
        return i == 3;
    }

    @Override
    public boolean tun_builder_set_mtu (int mtu) {
        try {
			builder.setMtu(mtu);
			return true;
		} catch (Exception e) {
			return false;
		}
    }

    @Override
    public boolean tun_builder_set_session_name (String name) {
        try {
			builder.setSession(name);
			return true;
		} catch (Exception e) {
			return false;
		}
    }
	
	@Override
    public int tun_builder_establish () {
        return builder.establish().detachFd();
    }
}
