package net.openvpn.openvpn;

public class SWIGTYPE_p_std__vectorT_openvpn__ClientAPI__KeyValue_t {
    private transient long swigCPtr;

    protected SWIGTYPE_p_std__vectorT_openvpn__ClientAPI__KeyValue_t() {
        this.swigCPtr = 0;
    }

    protected SWIGTYPE_p_std__vectorT_openvpn__ClientAPI__KeyValue_t(long j, boolean z) {
        this.swigCPtr = j;
    }

    protected static long getCPtr(SWIGTYPE_p_std__vectorT_openvpn__ClientAPI__KeyValue_t sWIGTYPE_p_std__vectorT_openvpn__ClientAPI__KeyValue_t) {
        return sWIGTYPE_p_std__vectorT_openvpn__ClientAPI__KeyValue_t == null ? 0 : sWIGTYPE_p_std__vectorT_openvpn__ClientAPI__KeyValue_t.swigCPtr;
    }
}
