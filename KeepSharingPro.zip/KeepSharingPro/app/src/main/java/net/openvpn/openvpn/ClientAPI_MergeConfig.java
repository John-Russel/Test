package net.openvpn.openvpn;

public class ClientAPI_MergeConfig {
    protected transient boolean swigCMemOwn;
    private transient long swigCPtr;

    public ClientAPI_MergeConfig() {
        this(ovpncliJNI.new_ClientAPI_MergeConfig(), true);
    }

    protected ClientAPI_MergeConfig(long j, boolean z) {
        this.swigCMemOwn = z;
        this.swigCPtr = j;
    }

    protected static long getCPtr(ClientAPI_MergeConfig clientAPI_MergeConfig) {
        return clientAPI_MergeConfig == null ? 0 : clientAPI_MergeConfig.swigCPtr;
    }

    public void delete() {
        synchronized (this) {
            if (this.swigCPtr != 0) {
                if (this.swigCMemOwn) {
                    this.swigCMemOwn = false;
                    ovpncliJNI.delete_ClientAPI_MergeConfig(this.swigCPtr);
                }
                this.swigCPtr = 0;
            }
        }
    }

    protected void finalize() {
        delete();
    }

    public String getBasename() {
        return ovpncliJNI.ClientAPI_MergeConfig_basename_get(this.swigCPtr, this);
    }

    public String getErrorText() {
        return ovpncliJNI.ClientAPI_MergeConfig_errorText_get(this.swigCPtr, this);
    }

    public String getProfileContent() {
        return ovpncliJNI.ClientAPI_MergeConfig_profileContent_get(this.swigCPtr, this);
    }

    public SWIGTYPE_p_std__vectorT_std__string_t getRefPathList() {
        long ClientAPI_MergeConfig_refPathList_get = ovpncliJNI.ClientAPI_MergeConfig_refPathList_get(this.swigCPtr, this);
        return ClientAPI_MergeConfig_refPathList_get == 0 ? null : new SWIGTYPE_p_std__vectorT_std__string_t(ClientAPI_MergeConfig_refPathList_get, false);
    }

    public String getStatus() {
        return ovpncliJNI.ClientAPI_MergeConfig_status_get(this.swigCPtr, this);
    }

    public void setBasename(String str) {
        ovpncliJNI.ClientAPI_MergeConfig_basename_set(this.swigCPtr, this, str);
    }

    public void setErrorText(String str) {
        ovpncliJNI.ClientAPI_MergeConfig_errorText_set(this.swigCPtr, this, str);
    }

    public void setProfileContent(String str) {
        ovpncliJNI.ClientAPI_MergeConfig_profileContent_set(this.swigCPtr, this, str);
    }

    public void setRefPathList(SWIGTYPE_p_std__vectorT_std__string_t sWIGTYPE_p_std__vectorT_std__string_t) {
        ovpncliJNI.ClientAPI_MergeConfig_refPathList_set(this.swigCPtr, this, SWIGTYPE_p_std__vectorT_std__string_t.getCPtr(sWIGTYPE_p_std__vectorT_std__string_t));
    }

    public void setStatus(String str) {
        ovpncliJNI.ClientAPI_MergeConfig_status_set(this.swigCPtr, this, str);
    }
}
