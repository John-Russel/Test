package net.openvpn.openvpn;

public class ClientAPI_LLVector {
    protected transient boolean swigCMemOwn;
    private transient long swigCPtr;

    public ClientAPI_LLVector() {
        this(ovpncliJNI.new_ClientAPI_LLVector__SWIG_0(), true);
    }

    public ClientAPI_LLVector(long j) {
        this(ovpncliJNI.new_ClientAPI_LLVector__SWIG_1(j), true);
    }

    protected ClientAPI_LLVector(long j, boolean z) {
        this.swigCMemOwn = z;
        this.swigCPtr = j;
    }

    protected static long getCPtr(ClientAPI_LLVector clientAPI_LLVector) {
        return clientAPI_LLVector == null ? 0 : clientAPI_LLVector.swigCPtr;
    }

    public void add(long j) {
        ovpncliJNI.ClientAPI_LLVector_add(this.swigCPtr, this, j);
    }

    public long capacity() {
        return ovpncliJNI.ClientAPI_LLVector_capacity(this.swigCPtr, this);
    }

    public void clear() {
        ovpncliJNI.ClientAPI_LLVector_clear(this.swigCPtr, this);
    }

    public void delete() {
        synchronized (this) {
            if (this.swigCPtr != 0) {
                if (this.swigCMemOwn) {
                    this.swigCMemOwn = false;
                    ovpncliJNI.delete_ClientAPI_LLVector(this.swigCPtr);
                }
                this.swigCPtr = 0;
            }
        }
    }

    protected void finalize() {
        delete();
    }

    public long get(int i) {
        return ovpncliJNI.ClientAPI_LLVector_get(this.swigCPtr, this, i);
    }

    public boolean isEmpty() {
        return ovpncliJNI.ClientAPI_LLVector_isEmpty(this.swigCPtr, this);
    }

    public void reserve(long j) {
        ovpncliJNI.ClientAPI_LLVector_reserve(this.swigCPtr, this, j);
    }

    public void set(int i, long j) {
        ovpncliJNI.ClientAPI_LLVector_set(this.swigCPtr, this, i, j);
    }

    public long size() {
        return ovpncliJNI.ClientAPI_LLVector_size(this.swigCPtr, this);
    }
}
