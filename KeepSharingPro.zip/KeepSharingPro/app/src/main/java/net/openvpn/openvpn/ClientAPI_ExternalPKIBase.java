package net.openvpn.openvpn;

public class ClientAPI_ExternalPKIBase {
    protected transient boolean swigCMemOwn;
    private transient long swigCPtr;

    protected ClientAPI_ExternalPKIBase(long j, boolean z) {
        this.swigCMemOwn = z;
        this.swigCPtr = j;
    }

    protected static long getCPtr(ClientAPI_ExternalPKIBase clientAPI_ExternalPKIBase) {
        return clientAPI_ExternalPKIBase == null ? 0 : clientAPI_ExternalPKIBase.swigCPtr;
    }

    public void delete() {
        synchronized (this) {
            if (this.swigCPtr != 0) {
                if (this.swigCMemOwn) {
                    this.swigCMemOwn = false;
                    ovpncliJNI.delete_ClientAPI_ExternalPKIBase(this.swigCPtr);
                }
                this.swigCPtr = 0;
            }
        }
    }

    protected void finalize() {
        delete();
    }

    public boolean sign(String str, SWIGTYPE_p_std__string sWIGTYPE_p_std__string) {
        return ovpncliJNI.ClientAPI_ExternalPKIBase_sign(this.swigCPtr, this, str, SWIGTYPE_p_std__string.getCPtr(sWIGTYPE_p_std__string));
    }
}
