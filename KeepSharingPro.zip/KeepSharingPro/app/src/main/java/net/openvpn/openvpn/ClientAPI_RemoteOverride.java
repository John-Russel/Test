package net.openvpn.openvpn;

public class ClientAPI_RemoteOverride {
    protected transient boolean swigCMemOwn;
    private transient long swigCPtr;

    public ClientAPI_RemoteOverride() {
        this(ovpncliJNI.new_ClientAPI_RemoteOverride(), true);
    }

    protected ClientAPI_RemoteOverride(long j, boolean z) {
        this.swigCMemOwn = z;
        this.swigCPtr = j;
    }

    protected static long getCPtr(ClientAPI_RemoteOverride clientAPI_RemoteOverride) {
        return clientAPI_RemoteOverride == null ? 0 : clientAPI_RemoteOverride.swigCPtr;
    }

    public void delete() {
        synchronized (this) {
            if (this.swigCPtr != 0) {
                if (this.swigCMemOwn) {
                    this.swigCMemOwn = false;
                    ovpncliJNI.delete_ClientAPI_RemoteOverride(this.swigCPtr);
                }
                this.swigCPtr = 0;
            }
        }
    }

    protected void finalize() {
        delete();
    }

    public String getHost() {
        return ovpncliJNI.ClientAPI_RemoteOverride_host_get(this.swigCPtr, this);
    }

    public String getIp() {
        return ovpncliJNI.ClientAPI_RemoteOverride_ip_get(this.swigCPtr, this);
    }

    public String getPort() {
        return ovpncliJNI.ClientAPI_RemoteOverride_port_get(this.swigCPtr, this);
    }

    public String getProto() {
        return ovpncliJNI.ClientAPI_RemoteOverride_proto_get(this.swigCPtr, this);
    }

    public void setHost(String str) {
        ovpncliJNI.ClientAPI_RemoteOverride_host_set(this.swigCPtr, this, str);
    }

    public void setIp(String str) {
        ovpncliJNI.ClientAPI_RemoteOverride_ip_set(this.swigCPtr, this, str);
    }

    public void setPort(String str) {
        ovpncliJNI.ClientAPI_RemoteOverride_port_set(this.swigCPtr, this, str);
    }

    public void setProto(String str) {
        ovpncliJNI.ClientAPI_RemoteOverride_proto_set(this.swigCPtr, this, str);
    }
}
