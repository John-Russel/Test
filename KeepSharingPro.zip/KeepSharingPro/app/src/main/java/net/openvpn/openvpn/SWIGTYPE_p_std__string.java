package net.openvpn.openvpn;

public class SWIGTYPE_p_std__string {
    private transient long swigCPtr;

    protected SWIGTYPE_p_std__string() {
        this.swigCPtr = 0;
    }

    protected SWIGTYPE_p_std__string(long j, boolean z) {
        this.swigCPtr = j;
    }

    protected static long getCPtr(SWIGTYPE_p_std__string sWIGTYPE_p_std__string) {
        return sWIGTYPE_p_std__string == null ? 0 : sWIGTYPE_p_std__string.swigCPtr;
    }
}
